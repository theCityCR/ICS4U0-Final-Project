The runnable JAR file contains the runnable JAR. 
The source code file contains all the source code. MainGame is the class that is actually responsible for running the program. 
All the files are only guranteed to work in jGrasp. 

When clicking, since we overrode Java's MouseClicked method, the mouse must not move between pressing down and releasing, otherwise Java will not recognize it as clicking. This does not affect shooting in the game as we only check for MousePress and MouseRelease. 
The game may be hard to get a grasp of as it is designed to be challenging. 